var fs = require('fs'),
express = require('express'),
http = require('http'),
app = express(),
router = require('dir-routes');

global.inMemoryPath = __dirname+'/users.db';
try { global.inMemoryDB = JSON.parse(fs.readFileSync(inMemoryPath, {encoding:'utf8'})); }
catch(e){ global.inMemoryDB = {}; }
global.snowflake = false;

app.use(router);

app.use(function(req, res) {
	res.status(404).end('404: Page not Found!!  =/');
});

var httpServer = http.createServer(app);

httpServer.listen(8080, function() {
	console.log('Listening on port %d', httpServer.address().port);
});