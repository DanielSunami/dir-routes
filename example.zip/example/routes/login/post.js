var qs = require('querystring');

module.exports = function(req, res){
	req.setEncoding('utf8');
	var body = '';
	req.on('data', function(chunk){ body += chunk; });
	req.on('end',function(){
		body = qs.parse(body);
		body.user = body.user.replace(/[^a-zA-Z]/g, "");
		if(inMemoryDB[body.user] === body.pwd){
			global.snowflake = true;
			res.redirect('/home');
		}else{
			res.send('<!DOCTYPE html><html><head><title>dir-routes example</title><style> h2, h1, small{text-align: center; display: block;} aside{border: 1px solid #eee; background: rgb(240, 240, 240);padding: 7px 8px;margin-left: .25em;margin-top: 1em; width: 98%;} hr{background-color: #fff; border-top: 2px dashed #8c8b8b; margin: 3em 0;}</style></head><body style="font-family: Arial;"><div style="margin: 0 auto; max-width: 900px;"><h1>Try Again!</h1><small><a href="/">back</a></small><hr/><h2>This Page!</h2><aside style="margin: 0 auto; max-width: 400px;">POST in <script>document.write(window.location.href);</script><br>File name: post.js<br>Full path: example/routes/login/post.js<br>Route: /login</aside></div></body></html>');
		}
	});
}